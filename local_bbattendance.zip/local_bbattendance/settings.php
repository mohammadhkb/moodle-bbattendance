<?php
defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) {
    $settings = new admin_settingpage('local_bbattendance', get_string('settings', 'local_bbattendance'));
    $ADMIN->add('localplugins', $settings);

    if ($ADMIN->fulltree) {
        $settings->add(new admin_setting_configpasswordunmask(
            'local_bbattendance/webhooktoken',
            get_string('webhooktoken', 'local_bbattendance'),
            get_string('webhooktoken_desc', 'local_bbattendance'),
            ''
        ));
        $settings->add(new admin_setting_configtext(
            'local_bbattendance/bbbdomain',
            get_string('bbbdomain', 'local_bbattendance'),
            get_string('bbbdomain_desc', 'local_bbattendance'),
            '',
            PARAM_HOST
        ));
    }
}
