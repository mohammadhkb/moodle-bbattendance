<?php
require(__DIR__ . '/../../config.php');

$courseid = required_param('courseid', PARAM_INT);
$download = optional_param('download', 0, PARAM_BOOL);
$course = get_course($courseid);
require_login($course);
$context = context_course::instance($courseid);
require_capability('local/bbattendance:viewreport', $context);

$PAGE->set_url(new moodle_url('/local/bbattendance/report.php', ['courseid' => $courseid]));
$PAGE->set_context($context);
$PAGE->set_title(get_string('reporttitle', 'local_bbattendance'));
$PAGE->set_heading(get_string('reporttitle', 'local_bbattendance'));

$sessions = $DB->get_records_sql(
    "SELECT a.*, u.firstname AS userfirstname, u.lastname AS userlastname,
            c.fullname AS coursename, b.name AS activityname
       FROM {local_bbattendance_sessions} a
  LEFT JOIN {user} u ON u.id = a.userid
  LEFT JOIN {course} c ON c.id = a.courseid
  LEFT JOIN {bigbluebuttonbn} b ON b.id = a.instanceid
      WHERE a.courseid = :courseid
   ORDER BY a.firstjoin ASC, a.id ASC",
    ['courseid' => $courseid]
);

/**
 * Format a number of seconds as HH:mm:ss (readable duration).
 *
 * @param int $seconds
 * @return string
 */
function bbattendance_format_duration(int $seconds): string {
    $seconds = max(0, $seconds);
    $hours = intdiv($seconds, 3600);
    $minutes = intdiv($seconds % 3600, 60);
    $secs = $seconds % 60;
    return sprintf('%02d:%02d:%02d', $hours, $minutes, $secs);
}

// Build one record per session: duration = last leave time - first join time.
$records = [];
foreach ($sessions as $s) {
    $firstjoin = (int)$s->firstjoin;
    $lastleave = (int)$s->lastleave;
    $duration = max(0, $lastleave - $firstjoin);

    $records[] = [
        'meetingid' => $s->meetingid,
        'userid' => (int)$s->userid,
        'fullname' => trim(($s->userfirstname ?? '') . ' ' . ($s->userlastname ?? '')) ?: ($s->fullname ?? ''),
        'role' => $s->role ?? '',
        'activityname' => $s->activityname ?? '',
        'firstjoin' => $firstjoin,
        'lastleave' => $lastleave,
        'duration' => $duration,
        'durationformatted' => bbattendance_format_duration($duration),
        'joins' => (int)($s->joins ?? 0),
        'active' => !empty($s->active),
    ];
}

if ($download) {
    $filename = 'bbb-attendance-course-' . $courseid . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Course ID', 'Course', 'Activity', 'Moodle user ID', 'Participant', 'BBB role',
        'Meeting ID', 'First join', 'Last leave', 'Duration (HH:mm:ss)', 'Duration (seconds)',
        'Join count', 'Status'], ',', '"', '');
    foreach ($records as $row) {
        fputcsv($out, [
            $courseid, $course->fullname, $row['activityname'], $row['userid'], $row['fullname'],
            $row['role'], $row['meetingid'],
            $row['firstjoin'] ? userdate($row['firstjoin'], '%Y-%m-%d %H:%M:%S') : '',
            $row['lastleave'] ? userdate($row['lastleave'], '%Y-%m-%d %H:%M:%S') : '',
            $row['durationformatted'], $row['duration'],
            $row['joins'], $row['active'] ? 'active' : 'left'
        ], ',', '"', '');
    }
    fclose($out);
    exit;
}

echo $OUTPUT->header();
echo $OUTPUT->heading(format_string($course->fullname));
echo html_writer::link(
    new moodle_url('/local/bbattendance/report.php', ['courseid' => $courseid, 'download' => 1]),
    get_string('downloadcsv', 'local_bbattendance'),
    ['class' => 'btn btn-secondary mb-3']
);

if (!$records) {
    echo $OUTPUT->notification(get_string('norecords', 'local_bbattendance'), 'info');
} else {
    $table = new html_table();
    $table->attributes['class'] = 'generaltable table table-striped';
    $table->head = [
        get_string('activity', 'local_bbattendance'),
        get_string('participant', 'local_bbattendance'),
        get_string('role', 'local_bbattendance'),
        get_string('firstjoin', 'local_bbattendance'),
        get_string('lastleave', 'local_bbattendance'),
        get_string('duration', 'local_bbattendance'),
        #get_string('joins', 'local_bbattendance'),
        get_string('status', 'local_bbattendance'),
    ];
    foreach ($records as $row) {
        $table->data[] = [
            format_string($row['activityname']),
            s($row['fullname']),
            s($row['role']),
            $row['firstjoin'] ? userdate($row['firstjoin']) : '-',
            $row['lastleave'] ? userdate($row['lastleave']) : '-',
            $row['durationformatted'],
            #(int)$row['joins'],
            $row['active'] ? get_string('active', 'local_bbattendance') : get_string('left', 'local_bbattendance'),
        ];
    }
    echo html_writer::table($table);
}
echo $OUTPUT->footer();
