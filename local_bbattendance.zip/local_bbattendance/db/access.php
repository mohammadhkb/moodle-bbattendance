<?php
defined('MOODLE_INTERNAL') || die();

$capabilities = [
    'local/bbattendance:viewreport' => [
        'captype' => 'read',
        'contextlevel' => CONTEXT_COURSE,
        'archetypes' => [
            'manager' => CAP_ALLOW,
            'editingteacher' => CAP_ALLOW,
            'teacher' => CAP_ALLOW,
        ],
        'riskbitmask' => RISK_PERSONAL,
    ],
];
