<?php
// BBB webhook receiver. This endpoint intentionally does not require a Moodle login.
require(__DIR__ . '/../../config.php');

function local_bbattendance_reply(int $status, string $message): void {
    http_response_code($status);
    header('Content-Type: text/plain; charset=utf-8');
    echo $message;
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    local_bbattendance_reply(405, 'POST required');
}

$expectedtoken = (string)get_config('local_bbattendance', 'webhooktoken');
if ($expectedtoken === '') {
    local_bbattendance_reply(503, 'Webhook is not configured');
}

$authorization = (string)($_SERVER['HTTP_AUTHORIZATION'] ?? '');
if ($authorization === '' && function_exists('getallheaders')) {
    $headers = getallheaders();
    foreach ($headers as $name => $value) {
        if (strtolower($name) === 'authorization') {
            $authorization = (string)$value;
            break;
        }
    }
}
if (!preg_match('/^Bearer\s+(.+)$/i', trim($authorization), $matches) ||
        !hash_equals($expectedtoken, trim($matches[1]))) {
    local_bbattendance_reply(401, 'Unauthorized');
}

$domain = (string)($_POST['domain'] ?? '');
$expecteddomain = trim((string)get_config('local_bbattendance', 'bbbdomain'));
if ($expecteddomain === '') {
    local_bbattendance_reply(503, 'BBB domain is not configured');
}
if (!hash_equals(strtolower($expecteddomain), strtolower($domain))) {
    local_bbattendance_reply(403, 'Unexpected BBB domain');
}

$rawevents = $_POST['event'] ?? '';
if (!is_string($rawevents) || $rawevents === '') {
    local_bbattendance_reply(400, 'Missing event payload');
}
$events = json_decode($rawevents, true);
if (!is_array($events)) {
    local_bbattendance_reply(400, 'Invalid event JSON');
}
if (isset($events['data'])) {
    $events = [$events];
}

$processed = 0;
$now = time();

foreach ($events as $event) {
    if (!is_array($event)) {
        continue;
    }
    $data = $event['data'] ?? [];
    $eventtype = (string)($data['id'] ?? '');
    $attrs = $data['attributes'] ?? [];
    $meeting = $attrs['meeting'] ?? [];
    $user = $attrs['user'] ?? [];
    $externalmeetingid = (string)($meeting['external-meeting-id'] ?? '');
    $internalmeetingid = (string)($meeting['internal-meeting-id'] ?? '');
    if ($eventtype === '' || $externalmeetingid === '' || $internalmeetingid === '') {
        continue;
    }

    $eventts = (int)($data['event']['ts'] ?? 0);
    $eventtime = $eventts > 0 ? (int)floor($eventts / 1000) : $now;
    $externaluserid = (string)($user['external-user-id'] ?? '');
    $internaluserid = (string)($user['internal-user-id'] ?? '');
    $eventkey = hash('sha256', implode('|', [
        $eventtype, $internalmeetingid, $externalmeetingid,
        $internaluserid, $externaluserid, (string)$eventts
    ]));

    // Webhooks can be retried. Record each event once.
    if ($DB->record_exists('local_bbattendance_events', ['eventkey' => $eventkey])) {
        continue;
    }
    $DB->insert_record('local_bbattendance_events', (object)[
        'eventkey' => $eventkey,
        'eventtype' => substr($eventtype, 0, 40),
        'meetingid' => $externalmeetingid,
        'eventts' => $eventts,
        'timecreated' => $now,
    ]);

    if (!preg_match('~^(.+)-([0-9]+)-([0-9]+)(?:\[([0-9]*)\])?$~', $externalmeetingid, $mm)) {
        $processed++;
        continue;
    }
    $courseid = (int)$mm[2];
    $instanceid = (int)$mm[3];
    $groupid = isset($mm[4]) && $mm[4] !== '' ? (int)$mm[4] : 0;
    $meetingkey = hash('sha256', $externalmeetingid);

    // Confirm that this meeting ID maps to a real Moodle BBB activity.
    if (!$DB->record_exists('bigbluebuttonbn', ['id' => $instanceid, 'course' => $courseid])) {
        $processed++;
        continue;
    }
    $cm = get_coursemodule_from_instance('bigbluebuttonbn', $instanceid, $courseid, false, IGNORE_MISSING);
    $cmid = $cm ? (int)$cm->id : 0;

    if ($eventtype === 'user-joined' || $eventtype === 'user-left') {
        // Guests and non-numeric external IDs are intentionally not linked to Moodle users.
        if (!empty($user['guest']) || !ctype_digit($externaluserid) || (int)$externaluserid < 1 ||
                $internaluserid === '') {
            $processed++;
            continue;
        }
        $userid = (int)$externaluserid;
        if (!$DB->record_exists('user', ['id' => $userid, 'deleted' => 0])) {
            $processed++;
            continue;
        }

        // Internal BBB user ID distinguishes a connection/session; aggregate sessions in the report.
        $sessionkey = hash('sha256', $meetingkey . '|' . $internaluserid . '|' . $userid);
        $session = $DB->get_record('local_bbattendance_sessions', ['sessionkey' => $sessionkey]);

        if ($eventtype === 'user-joined') {
            $fullname = trim((string)($user['name'] ?? ''));
            $role = strtoupper(substr((string)($user['role'] ?? ''), 0, 20));
            if (!$session) {
                $DB->insert_record('local_bbattendance_sessions', (object)[
                    'sessionkey' => $sessionkey,
                    'meetingkey' => $meetingkey,
                    'meetingid' => $externalmeetingid,
                    'internalmeetingid' => $internalmeetingid,
                    'courseid' => $courseid,
                    'instanceid' => $instanceid,
                    'cmid' => $cmid,
                    'groupid' => $groupid,
                    'userid' => $userid,
                    'externaluserid' => $externaluserid,
                    'internaluserid' => $internaluserid,
                    'fullname' => $fullname,
                    'role' => $role,
                    'firstjoin' => $eventtime,
                    'lastjoin' => $eventtime,
                    'lastleave' => 0,
                    'totalseconds' => 0,
                    'joins' => 1,
                    'active' => 1,
                    'timecreated' => $now,
                    'timemodified' => $now,
                ]);
            } else {
                $session->fullname = $fullname !== '' ? $fullname : $session->fullname;
                $session->role = $role !== '' ? $role : $session->role;
                if (empty($session->active)) {
                    $session->lastjoin = $eventtime;
                    $session->active = 1;
                    $session->joins = (int)$session->joins + 1;
                }
                $session->timemodified = $now;
                $DB->update_record('local_bbattendance_sessions', $session);
            }
        } else {
            if (!$session) {
                // Fallback if a BBB reconnect changed the internal ID: close the most recent active session.
                $matches = $DB->get_records_sql(
                    "SELECT * FROM {local_bbattendance_sessions}
                      WHERE meetingkey = :meetingkey AND userid = :userid AND active = 1
                   ORDER BY lastjoin DESC",
                    ['meetingkey' => $meetingkey, 'userid' => $userid],
                    0, 1
                );
                $session = $matches ? reset($matches) : false;
            }
            if ($session && !empty($session->active)) {
                $session->totalseconds = (int)$session->totalseconds + max(0, $eventtime - (int)$session->lastjoin);
                $session->lastleave = $eventtime;
                $session->active = 0;
                $session->timemodified = $now;
                $DB->update_record('local_bbattendance_sessions', $session);
            }
        }
    } else if ($eventtype === 'meeting-ended') {
        $active = $DB->get_records('local_bbattendance_sessions', ['meetingkey' => $meetingkey, 'active' => 1]);
        foreach ($active as $session) {
            $session->totalseconds = (int)$session->totalseconds + max(0, $eventtime - (int)$session->lastjoin);
            $session->lastleave = $eventtime;
            $session->active = 0;
            $session->timemodified = $now;
            $DB->update_record('local_bbattendance_sessions', $session);
        }
    }
    $processed++;
}

local_bbattendance_reply(200, 'OK ' . $processed);
