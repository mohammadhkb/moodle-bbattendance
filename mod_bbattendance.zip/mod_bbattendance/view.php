<?php
require('../../config.php');
require_once($CFG->dirroot . '/course/lib.php');

$id = required_param('id', PARAM_INT); // Course module ID.
$cm = get_coursemodule_from_id('bbattendance', $id, 0, false, MUST_EXIST);
$course = get_course($cm->course);
$instance = $DB->get_record('bbattendance', array('id' => $cm->instance), '*', MUST_EXIST);

require_login($course, true, $cm);
$context = context_module::instance($cm->id);
$coursecontext = context_course::instance($course->id);

require_capability('mod/bbattendance:viewreport', $context);
require_capability('local/bbattendance:viewreport', $coursecontext);

$target = new moodle_url('/local/bbattendance/report.php', array('courseid' => $course->id));
redirect($target);
