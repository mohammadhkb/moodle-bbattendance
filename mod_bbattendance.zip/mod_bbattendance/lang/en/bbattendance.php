<?php
$string['pluginname'] = 'BBB attendance report';
$string['modulename'] = 'BBB attendance report';
$string['modulenameplural'] = 'BBB attendance reports';
$string['modulename_help'] = 'Adds a course activity that opens the BigBlueButton attendance report for teachers and managers.';
$string['privacy:metadata'] = 'This activity does not store attendance events; it links to the local_bbattendance report.';
$string['viewreport'] = 'View BBB attendance report';
$string['bbattendance:addinstance'] = 'Add a BBB attendance report activity';
$string['bbattendance:viewreport'] = 'View the BBB attendance report';
