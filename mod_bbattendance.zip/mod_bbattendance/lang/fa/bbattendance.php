<?php
$string['pluginname'] = 'گزارش حضور و غیاب BBB';
$string['modulename'] = 'گزارش حضور و غیاب BBB';
$string['modulenameplural'] = 'گزارش‌های حضور و غیاب BBB';
$string['modulename_help'] = 'فعالیتی برای نمایش گزارش حضور و غیاب بیگ‌بلو‌باتن برای استادان و مدیران مجاز.';
$string['privacy:metadata'] = 'این فعالیت رویدادهای حضور و غیاب را ذخیره نمی‌کند و فقط به گزارش افزونه local_bbattendance پیوند می‌دهد.';
$string['viewreport'] = 'مشاهده گزارش حضور و غیاب BBB';
$string['bbattendance:addinstance'] = 'افزودن فعالیت گزارش حضور و غیاب BBB';
$string['bbattendance:viewreport'] = 'مشاهده گزارش حضور و غیاب BBB';
