<?php
defined('MOODLE_INTERNAL') || die();

function bbattendance_supports($feature) {
    switch ($feature) {
        case FEATURE_MOD_INTRO:
        case FEATURE_SHOW_DESCRIPTION:
        case FEATURE_BACKUP_MOODLE2:
            return true;
        default:
            return null;
    }
}

function bbattendance_add_instance($data, $mform = null) {
    global $DB;
    $data->timecreated = time();
    $data->timemodified = time();
    return $DB->insert_record('bbattendance', $data);
}

function bbattendance_update_instance($data, $mform = null) {
    global $DB;
    $data->timemodified = time();
    $data->id = $data->instance;
    return $DB->update_record('bbattendance', $data);
}

function bbattendance_delete_instance($id) {
    global $DB;
    if (!$record = $DB->get_record('bbattendance', array('id' => $id))) {
        return false;
    }
    $DB->delete_records('bbattendance', array('id' => $id));
    return true;
}
