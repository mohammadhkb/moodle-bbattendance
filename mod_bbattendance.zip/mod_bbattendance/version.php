<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_bbattendance';
$plugin->version   = 2026101500;
$plugin->requires = 2026042000;
$plugin->maturity = MATURITY_ALPHA;
$plugin->release   = '0.2.0-alpha';
